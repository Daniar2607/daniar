import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertContactMessageSchema, insertNewsletterSchema } from "@shared/schema";
import { ZodError } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes
  
  // GET menu items
  app.get("/api/menu", async (req, res) => {
    try {
      const menuItems = await storage.getAllMenuItems();
      return res.json(menuItems);
    } catch (error) {
      console.error("Error fetching menu items:", error);
      return res.status(500).json({ message: "Failed to fetch menu items" });
    }
  });
  
  // GET menu items by category
  app.get("/api/menu/:category", async (req, res) => {
    try {
      const { category } = req.params;
      const menuItems = await storage.getMenuItemsByCategory(category);
      return res.json(menuItems);
    } catch (error) {
      console.error(`Error fetching menu items for category ${req.params.category}:`, error);
      return res.status(500).json({ message: "Failed to fetch menu items" });
    }
  });
  
  // POST contact form
  app.post("/api/contact", async (req, res) => {
    try {
      const data = insertContactMessageSchema.parse({
        ...req.body,
        createdAt: new Date().toISOString()
      });
      
      const message = await storage.createContactMessage(data);
      return res.status(201).json({ message: "Message sent successfully", data: message });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid form data", errors: error.errors });
      }
      
      console.error("Error saving contact message:", error);
      return res.status(500).json({ message: "Failed to send message" });
    }
  });
  
  // POST newsletter subscription
  app.post("/api/newsletter", async (req, res) => {
    try {
      const data = insertNewsletterSchema.parse({
        ...req.body,
        createdAt: new Date().toISOString()
      });
      
      const existingSubscription = await storage.getNewsletterByEmail(data.email);
      if (existingSubscription) {
        return res.status(200).json({ message: "You are already subscribed" });
      }
      
      const subscription = await storage.createNewsletter(data);
      return res.status(201).json({ message: "Subscribed successfully", data: subscription });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid email", errors: error.errors });
      }
      
      console.error("Error subscribing to newsletter:", error);
      return res.status(500).json({ message: "Failed to subscribe" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
