import { 
  users, type User, type InsertUser,
  type MenuItem, type InsertMenuItem, 
  type ContactMessage, type InsertContactMessage,
  type Newsletter, type InsertNewsletter
} from "@shared/schema";

// Storage interface
export interface IStorage {
  // User methods from original template
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Menu methods
  getAllMenuItems(): Promise<MenuItem[]>;
  getMenuItemsByCategory(category: string): Promise<MenuItem[]>;
  getMenuItem(id: number): Promise<MenuItem | undefined>;
  createMenuItem(item: InsertMenuItem): Promise<MenuItem>;
  
  // Contact form methods
  createContactMessage(message: InsertContactMessage): Promise<ContactMessage>;
  
  // Newsletter methods
  createNewsletter(newsletter: InsertNewsletter): Promise<Newsletter>;
  getNewsletterByEmail(email: string): Promise<Newsletter | undefined>;
}

// In-memory storage implementation
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private menuItems: Map<number, MenuItem>;
  private contactMessages: Map<number, ContactMessage>;
  private newsletters: Map<number, Newsletter>;
  
  private userId: number;
  private menuItemId: number;
  private contactMessageId: number;
  private newsletterId: number;

  constructor() {
    this.users = new Map();
    this.menuItems = new Map();
    this.contactMessages = new Map();
    this.newsletters = new Map();
    
    this.userId = 1;
    this.menuItemId = 1;
    this.contactMessageId = 1;
    this.newsletterId = 1;
    
    // Initialize with some sample menu items
    this.initSampleData();
  }
  
  private initSampleData() {
    // Coffee items
    const coffeeItems = [
      {
        name: "Эспрессо",
        description: "Классикалық италиялық эспрессо, қою және дәмді.",
        price: 1200,
        category: "coffee",
        imageUrl: "https://images.unsplash.com/photo-1510591509098-f4fdc6d0ff04?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
      },
      {
        name: "Латте",
        description: "Жұмсақ эспрессо бұқтырылған сүтпен біріктірілген.",
        price: 1800,
        category: "coffee",
        imageUrl: "https://images.unsplash.com/photo-1541167760496-1628856ab772?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
      },
      {
        name: "Капучино",
        description: "Теңдестірілген эспрессо, бумен бұқтырылған сүт және сүт көбігі.",
        price: 1700,
        category: "coffee",
        imageUrl: "https://images.unsplash.com/photo-1534778101976-62847782c213?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
      }
    ];
    
    // Tea items
    const teaItems = [
      {
        name: "Жасыл шай",
        description: "Жапон жасыл шайы, жаңа жапырақтардан демделген.",
        price: 1200,
        category: "tea",
        imageUrl: "https://images.unsplash.com/photo-1564890369478-c89ca6d9cde9?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
      },
      {
        name: "Қара шай",
        description: "Цейлон қара шайы, лимон немесе бал қосымшасымен.",
        price: 1100,
        category: "tea",
        imageUrl: "https://images.unsplash.com/photo-1576092768241-dec231879fc3?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
      }
    ];
    
    // Dessert items
    const dessertItems = [
      {
        name: "Шоколадты торт",
        description: "Бельгиялық шоколадтан жасалған біздің арнайы рецептіміз.",
        price: 2200,
        category: "desserts",
        imageUrl: "https://images.unsplash.com/photo-1578985545062-69928b1d9587?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
      },
      {
        name: "Чизкейк",
        description: "Жеңіл және кремді чизкейк, жаңа жидектермен.",
        price: 2300,
        category: "desserts",
        imageUrl: "https://images.unsplash.com/photo-1528207776546-365bb710ee93?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
      }
    ];
    
    // Breakfast items
    const breakfastItems = [
      {
        name: "Авокадо тосты",
        description: "Қытырлақ тосттар үстінде авокадо пастасы, қызанақпен.",
        price: 2500,
        category: "breakfast",
        imageUrl: "https://images.unsplash.com/photo-1525351484163-7529414344d8?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
      },
      {
        name: "Үйдегі гранола",
        description: "Жаңғақтармен және жемістермен дайындалған үйдегі гранола, йогуртпен.",
        price: 2100,
        category: "breakfast",
        imageUrl: "https://images.unsplash.com/photo-1505253716362-afaea1d3d1af?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"
      }
    ];
    
    // Add all items to the menu
    [...coffeeItems, ...teaItems, ...dessertItems, ...breakfastItems].forEach(item => {
      const menuItem: MenuItem = {
        ...item,
        id: this.menuItemId++
      };
      this.menuItems.set(menuItem.id, menuItem);
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Menu methods
  async getAllMenuItems(): Promise<MenuItem[]> {
    return Array.from(this.menuItems.values());
  }
  
  async getMenuItemsByCategory(category: string): Promise<MenuItem[]> {
    return Array.from(this.menuItems.values()).filter(
      (item) => item.category === category
    );
  }
  
  async getMenuItem(id: number): Promise<MenuItem | undefined> {
    return this.menuItems.get(id);
  }
  
  async createMenuItem(insertItem: InsertMenuItem): Promise<MenuItem> {
    const id = this.menuItemId++;
    const menuItem: MenuItem = { ...insertItem, id };
    this.menuItems.set(id, menuItem);
    return menuItem;
  }
  
  // Contact form methods
  async createContactMessage(insertMessage: InsertContactMessage): Promise<ContactMessage> {
    const id = this.contactMessageId++;
    const message: ContactMessage = { ...insertMessage, id };
    this.contactMessages.set(id, message);
    return message;
  }
  
  // Newsletter methods
  async createNewsletter(insertNewsletter: InsertNewsletter): Promise<Newsletter> {
    const id = this.newsletterId++;
    const newsletter: Newsletter = { ...insertNewsletter, id };
    this.newsletters.set(id, newsletter);
    return newsletter;
  }
  
  async getNewsletterByEmail(email: string): Promise<Newsletter | undefined> {
    return Array.from(this.newsletters.values()).find(
      (newsletter) => newsletter.email === email
    );
  }
}

export const storage = new MemStorage();
