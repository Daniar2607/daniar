import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import Features from "@/components/Features";
import Menu from "@/components/Menu";
import About from "@/components/About";
import Gallery from "@/components/Gallery";
import Contact from "@/components/Contact";
import Location from "@/components/Location";
import Footer from "@/components/Footer";
import CoffeeModel from "@/components/CoffeeModel";
import { useQuery } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import { MenuItem } from "@shared/schema";

export default function Home() {
  const { data: menuItems, isLoading } = useQuery<MenuItem[]>({
    queryKey: ["/api/menu"],
  });

  // Handle smooth scrolling for anchor links
  useEffect(() => {
    const handleAnchorClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      const anchor = target.closest('a[href^="#"]');
      
      if (anchor) {
        e.preventDefault();
        const targetId = anchor.getAttribute('href');
        
        if (targetId && targetId !== '#') {
          const targetElement = document.querySelector(targetId);
          if (targetElement) {
            window.scrollTo({
              top: targetElement.offsetTop - 80, // Adjust for header height
              behavior: 'smooth'
            });
          }
        }
      }
    };

    document.addEventListener('click', handleAnchorClick);
    
    return () => {
      document.removeEventListener('click', handleAnchorClick);
    };
  }, []);
  
  return (
    <div className="font-inter bg-[hsl(var(--coffee-light))] text-[hsl(var(--coffee-dark))]">
      <Navbar />
      <Hero />
      <div className="bg-white py-10">
        <div className="container mx-auto px-4">
          <div className="text-center mb-8">
            <h2 className="font-playfair text-3xl font-bold text-[hsl(var(--coffee-primary))]">Біздің кофехана</h2>
            <p className="text-gray-600 mt-2">Жетісу 2 16а мекен-жайында орналасқан</p>
          </div>
          <CoffeeModel />
        </div>
      </div>
      <Features />
      <Menu items={menuItems || []} isLoading={isLoading} />
      <About />
      <Gallery />
      <Contact />
      <Location />
      <Footer />
    </div>
  );
}
