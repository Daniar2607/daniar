export default function Gallery() {
  const galleryImages = [
    {
      src: "https://images.unsplash.com/photo-1512568400610-62da28bc8a13?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600",
      alt: "Бариста жұмыс үстінде"
    },
    {
      src: "https://images.unsplash.com/photo-1611854779393-1b2da9d400fe?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600",
      alt: "Кофе дәндері"
    },
    {
      src: "https://images.unsplash.com/photo-1534040385115-33dcb3acba5b?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600",
      alt: "Кофеханада демалу"
    },
    {
      src: "https://images.unsplash.com/photo-1541167760496-1628856ab772?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600",
      alt: "Латте өнері"
    }
  ];

  return (
    <section className="py-16 bg-[hsl(var(--coffee-light))]">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="font-playfair text-4xl font-bold mb-4">Біздің галерея</h2>
          <p className="text-gray-600 max-w-xl mx-auto">Біздің дүкеніміздің сәттері мен атмосферасы</p>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {galleryImages.map((image, index) => (
            <div key={index} className="overflow-hidden rounded-lg shadow-md">
              <img 
                src={image.src} 
                alt={image.alt} 
                className="w-full h-64 object-cover transform hover:scale-105 transition duration-500" 
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
