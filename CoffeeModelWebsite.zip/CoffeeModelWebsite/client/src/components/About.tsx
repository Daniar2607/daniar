import { Button } from "@/components/ui/button";

export default function About() {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
          <div className="order-2 md:order-1">
            <h2 className="font-playfair text-4xl font-bold mb-6">Біздің тарих</h2>
            <p className="text-gray-600 mb-4">
              Café Aroma 2010 жылы бір ғана мақсатпен құрылды – адамдарға сапалы кофе әлемін таныстыру. 
              Біздің негізін қалаушыларымыз Әсел мен Болат кофе жасау өнерін әлемнің түкпір-түкпірінде үйренді.
            </p>
            <p className="text-gray-600 mb-4">
              Біз тек ең жақсы кофе дәндерін таңдаймыз және оларды өзіміздің дүкенімізде қуырамыз. 
              Кофенің әр тостағы қолмен жасалады және біздің кофе мамандарымыздың махаббатымен дайындалады.
            </p>
            <p className="text-gray-600 mb-6">
              Біздің мақсатымыз – тек кофе сату емес, бірақ кофе мәдениетін дамыту және тамаша кофе тәжірибесін ұсыну.
            </p>
            <div className="flex space-x-4">
              <a href="#contact">
                <Button className="bg-[hsl(var(--coffee-primary))] hover:bg-[hsl(var(--coffee-accent))] text-white rounded-full">
                  Бізбен хабарласыңыз
                </Button>
              </a>
            </div>
          </div>
          <div className="order-1 md:order-2">
            <img 
              src="https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800" 
              alt="Біздің кофеханамыз" 
              className="rounded-lg shadow-xl w-full h-auto" 
            />
          </div>
        </div>
      </div>
    </section>
  );
}
