import { Coffee, Croissant, Home } from "lucide-react";

export default function Features() {
  const features = [
    {
      icon: <Coffee className="h-6 w-6 text-[hsl(var(--coffee-primary))]" />,
      title: "Ерекше кофе",
      description: "Әлемнің ең жақсы кофе дәндерінен жасалған сапалы кофе сусындары.",
      delay: 0
    },
    {
      icon: <Croissant className="h-6 w-6 text-[hsl(var(--coffee-primary))]" />,
      title: "Дәмді тағамдар",
      description: "Кофеңізге қосымша балғын пісірілген нандар мен тәтті тағамдар.",
      delay: 0.2
    },
    {
      icon: <Home className="h-6 w-6 text-[hsl(var(--coffee-primary))]" />,
      title: "Жайлы атмосфера",
      description: "Демалуға немесе жұмыс істеуге ыңғайлы жылы және жайлы орта.",
      delay: 0.4
    }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="flex flex-col items-center text-center p-6 animate-fade-in"
              style={{ animationDelay: `${feature.delay}s` }}
            >
              <div className="w-16 h-16 rounded-full bg-[hsl(var(--coffee-secondary))] flex items-center justify-center mb-4">
                {feature.icon}
              </div>
              <h3 className="font-playfair text-xl font-semibold mb-3">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
