import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Facebook, Instagram, Twitter } from "lucide-react";

export default function Contact() {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: ""
  });
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Form validation
    if (!formData.name || !formData.email || !formData.message) {
      toast({
        title: "Validation Error",
        description: "Please fill out all fields",
        variant: "destructive"
      });
      return;
    }
    
    // Here you would typically send the form data to the server
    // For now we'll just show a success message
    toast({
      title: "Form Submitted",
      description: "Thank you for your message. We'll get back to you soon!",
    });
    
    // Reset form
    setFormData({ name: "", email: "", message: "" });
  };
  
  return (
    <section id="contact" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
          <div>
            <h2 className="font-playfair text-4xl font-bold mb-6">Бізбен байланысыңыз</h2>
            <p className="text-gray-600 mb-8">Сұрақтарыңыз бар ма? Бізге хабарласыңыз, біз сізге көмектесуге қуаныштымыз.</p>
            
            <div className="mb-8">
              <h3 className="font-playfair text-xl font-semibold mb-4">Жұмыс уақыты</h3>
              <div className="flex justify-between mb-2">
                <span className="text-gray-600">Дүйсенбі - Жұма</span>
                <span className="font-medium">7:00 - 21:00</span>
              </div>
              <div className="flex justify-between mb-2">
                <span className="text-gray-600">Сенбі - Жексенбі</span>
                <span className="font-medium">8:00 - 22:00</span>
              </div>
            </div>
            
            <div className="mb-8">
              <h3 className="font-playfair text-xl font-semibold mb-4">Мекен-жайымыз</h3>
              <p className="text-gray-600 mb-2">Жетісу 2 16а, Алматы қаласы</p>
              <p className="text-gray-600 mb-2">Телефон: +7 775 132 4565</p>
              <p className="text-gray-600">Email: info@cafearoma.kz</p>
            </div>
            
            <div className="flex space-x-4">
              <a href="#" className="w-10 h-10 rounded-full bg-[hsl(var(--coffee-primary))] text-white flex items-center justify-center hover:bg-[hsl(var(--coffee-accent))] transition-colors">
                <Facebook size={18} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-[hsl(var(--coffee-primary))] text-white flex items-center justify-center hover:bg-[hsl(var(--coffee-accent))] transition-colors">
                <Instagram size={18} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-[hsl(var(--coffee-primary))] text-white flex items-center justify-center hover:bg-[hsl(var(--coffee-accent))] transition-colors">
                <Twitter size={18} />
              </a>
            </div>
          </div>
          
          <div>
            <Card className="bg-[hsl(var(--coffee-light))] p-8 rounded-lg shadow-md">
              <form onSubmit={handleSubmit}>
                <div className="mb-6">
                  <label htmlFor="name" className="block text-gray-700 font-medium mb-2">Толық аты-жөніңіз</label>
                  <Input 
                    type="text" 
                    id="name" 
                    value={formData.name}
                    onChange={handleChange}
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[hsl(var(--coffee-primary))] focus:outline-none" 
                    placeholder="Толық атыңызды енгізіңіз" 
                  />
                </div>
                
                <div className="mb-6">
                  <label htmlFor="email" className="block text-gray-700 font-medium mb-2">Email</label>
                  <Input 
                    type="email" 
                    id="email" 
                    value={formData.email}
                    onChange={handleChange}
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[hsl(var(--coffee-primary))] focus:outline-none" 
                    placeholder="Email адресіңізді енгізіңіз" 
                  />
                </div>
                
                <div className="mb-6">
                  <label htmlFor="message" className="block text-gray-700 font-medium mb-2">Хабарлама</label>
                  <Textarea 
                    id="message" 
                    rows={4} 
                    value={formData.message}
                    onChange={handleChange}
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[hsl(var(--coffee-primary))] focus:outline-none" 
                    placeholder="Хабарламаңызды жазыңыз"
                  />
                </div>
                
                <Button 
                  type="submit" 
                  className="w-full bg-[hsl(var(--coffee-primary))] hover:bg-[hsl(var(--coffee-accent))] text-white font-medium py-6 rounded-lg"
                >
                  Жіберу
                </Button>
              </form>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}
