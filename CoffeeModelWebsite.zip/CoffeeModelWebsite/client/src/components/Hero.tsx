import { Button } from "@/components/ui/button";

export default function Hero() {
  return (
    <section id="home" className="relative h-[90vh] bg-[hsl(var(--coffee-dark))] overflow-hidden">
      {/* Overlay */}
      <div className="absolute inset-0 bg-black opacity-40 z-10"></div>
      <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black opacity-60 z-10"></div>
      
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080" 
          alt="Specialty coffee brewing" 
          className="object-cover w-full h-full" 
        />
      </div>
      
      {/* Content */}
      <div className="container mx-auto px-4 h-full flex items-center relative z-20">
        <div className="max-w-xl animate-fade-in">
          <h1 className="font-playfair text-4xl md:text-6xl font-bold text-white leading-tight mb-4">
            Дәмді кофе әлеміне қош келдіңіз
          </h1>
          <p className="text-xl text-[hsl(var(--coffee-secondary))] mb-8">
            Күніңізді керемет етіп өткізуге арналған ең жақсы кофе таңдаулары
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <a href="#menu">
              <Button className="w-full sm:w-auto bg-[hsl(var(--coffee-primary))] hover:bg-[hsl(var(--coffee-accent))] text-white font-medium py-6 px-8 rounded-full">
                Мәзірді көру
              </Button>
            </a>
            <a href="#about">
              <Button variant="outline" className="w-full sm:w-auto bg-transparent border-2 border-white text-white font-medium py-6 px-8 rounded-full hover:bg-white hover:text-[hsl(var(--coffee-dark))]">
                Біз туралы
              </Button>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
