import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Menu, X } from "lucide-react";

export default function Navbar() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };
  
  const closeMobileMenu = () => {
    setIsMobileMenuOpen(false);
  };
  
  return (
    <header className="sticky top-0 bg-white bg-opacity-95 shadow-sm z-50">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <a href="#" className="flex items-center">
            <span className="font-playfair text-2xl md:text-3xl font-bold text-[hsl(var(--coffee-primary))]">Café Aroma</span>
          </a>
          
          {/* Mobile menu button */}
          <button 
            onClick={toggleMobileMenu}
            className="md:hidden text-[hsl(var(--coffee-dark))] focus:outline-none"
            aria-label="Toggle menu"
          >
            {isMobileMenuOpen ? 
              <X className="h-6 w-6" /> : 
              <Menu className="h-6 w-6" />
            }
          </button>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            <a href="#home" className="text-[hsl(var(--coffee-dark))] hover:text-[hsl(var(--coffee-primary))] transition-colors font-medium">Басты бет</a>
            <a href="#menu" className="text-[hsl(var(--coffee-dark))] hover:text-[hsl(var(--coffee-primary))] transition-colors font-medium">Мәзір</a>
            <a href="#about" className="text-[hsl(var(--coffee-dark))] hover:text-[hsl(var(--coffee-primary))] transition-colors font-medium">Біз туралы</a>
            <a href="#contact" className="text-[hsl(var(--coffee-dark))] hover:text-[hsl(var(--coffee-primary))] transition-colors font-medium">Байланыс</a>
          </nav>
          
          {/* Order button */}
          <a href="#order" className="hidden md:block">
            <Button className="bg-[hsl(var(--coffee-primary))] hover:bg-[hsl(var(--coffee-accent))] text-white rounded-full">
              Тапсырыс беру
            </Button>
          </a>
        </div>
        
        {/* Mobile Navigation */}
        {isMobileMenuOpen && (
          <div className="md:hidden mt-4 pb-2 animate-fade-in">
            <div className="flex flex-col space-y-3">
              <a 
                href="#home" 
                className="text-[hsl(var(--coffee-dark))] hover:text-[hsl(var(--coffee-primary))] transition-colors font-medium py-2"
                onClick={closeMobileMenu}
              >
                Басты бет
              </a>
              <a 
                href="#menu" 
                className="text-[hsl(var(--coffee-dark))] hover:text-[hsl(var(--coffee-primary))] transition-colors font-medium py-2"
                onClick={closeMobileMenu}
              >
                Мәзір
              </a>
              <a 
                href="#about" 
                className="text-[hsl(var(--coffee-dark))] hover:text-[hsl(var(--coffee-primary))] transition-colors font-medium py-2"
                onClick={closeMobileMenu}
              >
                Біз туралы
              </a>
              <a 
                href="#contact" 
                className="text-[hsl(var(--coffee-dark))] hover:text-[hsl(var(--coffee-primary))] transition-colors font-medium py-2"
                onClick={closeMobileMenu}
              >
                Байланыс
              </a>
              <a 
                href="#order" 
                className="bg-[hsl(var(--coffee-primary))] hover:bg-[hsl(var(--coffee-accent))] text-white py-2 px-6 rounded-full transition-colors font-medium text-center mt-2"
                onClick={closeMobileMenu}
              >
                Тапсырыс беру
              </a>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
