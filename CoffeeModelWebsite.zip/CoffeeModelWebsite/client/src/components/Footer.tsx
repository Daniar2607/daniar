import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Facebook, Instagram, Twitter, MapPin, Phone, Mail, Send } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";

export default function Footer() {
  const { toast } = useToast();
  const [email, setEmail] = useState("");
  
  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email) {
      toast({
        title: "Error",
        description: "Please enter your email address",
        variant: "destructive"
      });
      return;
    }
    
    toast({
      title: "Success",
      description: "Thank you for subscribing to our newsletter!"
    });
    
    setEmail("");
  };
  
  return (
    <footer className="bg-[hsl(var(--coffee-dark))] text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <a href="#" className="font-playfair text-2xl font-bold text-[hsl(var(--coffee-secondary))] mb-4 inline-block">Café Aroma</a>
            <p className="text-gray-400 mb-4">Дәмді кофе, ыстық шай және керемет тағамдардың үйі.</p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Facebook size={18} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Instagram size={18} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Twitter size={18} />
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="font-medium text-lg mb-4">Қызмет көрсету</h4>
            <ul className="space-y-2">
              <li><a href="#menu" className="text-gray-400 hover:text-white transition-colors">Мәзір</a></li>
              <li><a href="#about" className="text-gray-400 hover:text-white transition-colors">Біз туралы</a></li>
              <li><a href="#contact" className="text-gray-400 hover:text-white transition-colors">Байланыс</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Блог</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-medium text-lg mb-4">Байланыс</h4>
            <ul className="space-y-2">
              <li className="flex items-start">
                <MapPin className="mt-1 mr-3 text-[hsl(var(--coffee-secondary))]" size={16} />
                <span className="text-gray-400">Жетісу 2 16а, Алматы қаласы</span>
              </li>
              <li className="flex items-start">
                <Phone className="mt-1 mr-3 text-[hsl(var(--coffee-secondary))]" size={16} />
                <span className="text-gray-400">+7 775 132 4565</span>
              </li>
              <li className="flex items-start">
                <Mail className="mt-1 mr-3 text-[hsl(var(--coffee-secondary))]" size={16} />
                <span className="text-gray-400">info@cafearoma.kz</span>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-medium text-lg mb-4">Жаңалықтар алыңыз</h4>
            <p className="text-gray-400 mb-4">Жаңа мәзір элементтері және арнайы ұсыныстар туралы білу үшін жазылыңыз.</p>
            <form className="flex" onSubmit={handleNewsletterSubmit}>
              <Input 
                type="email" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Email адресіңіз" 
                className="px-4 py-2 rounded-l-lg border-0 focus:outline-none text-[hsl(var(--coffee-dark))] w-full" 
              />
              <Button 
                type="submit" 
                className="bg-[hsl(var(--coffee-primary))] hover:bg-[hsl(var(--coffee-accent))] text-white px-4 py-2 rounded-r-lg"
              >
                <Send size={18} />
              </Button>
            </form>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-10 pt-6 text-center text-gray-500">
          <p>&copy; {new Date().getFullYear()} Café Aroma. Барлық құқықтар қорғалған.</p>
        </div>
      </div>
    </footer>
  );
}
