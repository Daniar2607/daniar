export default function Location() {
  return (
    <section className="py-16 bg-[hsl(var(--coffee-light))]">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="font-playfair text-4xl font-bold mb-4">Біздің орналасқан жеріміз</h2>
          <p className="text-gray-600 max-w-xl mx-auto">Мекен-жайымыз: Жетісу 2 16а, Алматы қаласы</p>
        </div>
        
        <div className="rounded-lg overflow-hidden shadow-lg h-96">
          <iframe 
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2908.063091952194!2d76.83694731193919!3d43.209927971297015!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x38836ef1c6e0516f%3A0x5483e1c4c869399!2zItCW0LXRgtGW0YHRgyAyIiDQvNC60YAuLCDQkNC70LzQsNGC0YssINCa0LDQt9Cw0YXRgdGC0LDQvQ!5e0!3m2!1sru!2sus!4v1652345678901!5m2!1sru!2sus" 
            width="100%" 
            height="100%" 
            style={{ border: 0 }} 
            allowFullScreen={true} 
            loading="lazy"
            title="Café Aroma location"
            aria-label="Google Maps showing the location of Café Aroma"
          />
        </div>
      </div>
    </section>
  );
}
