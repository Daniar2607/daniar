import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { MenuItem } from "@shared/schema";

interface MenuProps {
  items: MenuItem[];
  isLoading: boolean;
}

export default function Menu({ items, isLoading }: MenuProps) {
  const [activeCategory, setActiveCategory] = useState("coffee");
  
  const categories = [
    { id: "coffee", name: "Кофе" },
    { id: "tea", name: "Шәй" },
    { id: "desserts", name: "Десерттер" },
    { id: "breakfast", name: "Таңғы ас" }
  ];
  
  const filteredItems = items.filter(item => item.category === activeCategory);
  
  const handleCategoryChange = (categoryId: string) => {
    setActiveCategory(categoryId);
  };
  
  return (
    <section id="menu" className="py-20 bg-[hsl(var(--coffee-light))]">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="font-playfair text-4xl font-bold mb-4">Біздің мәзір</h2>
          <p className="text-gray-600 max-w-xl mx-auto">Ең дәмді кофе мен тағам таңдауларымызды көріңіз</p>
        </div>
        
        {/* Menu Categories Tabs */}
        <div className="flex flex-wrap justify-center mb-12">
          {categories.map(category => (
            <button
              key={category.id}
              className={`py-2 px-6 mx-2 mb-2 rounded-full font-medium transition-colors ${
                activeCategory === category.id
                  ? "bg-[hsl(var(--coffee-primary))] text-white"
                  : "bg-[hsl(var(--coffee-secondary))] text-[hsl(var(--coffee-dark))]"
              }`}
              onClick={() => handleCategoryChange(category.id)}
            >
              {category.name}
            </button>
          ))}
        </div>
        
        {/* Menu Items */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {isLoading ? (
            // Loading skeletons
            Array(6).fill(0).map((_, index) => (
              <Card key={index} className="overflow-hidden">
                <Skeleton className="h-48 w-full" />
                <CardContent className="p-6">
                  <div className="flex justify-between items-start mb-2">
                    <Skeleton className="h-7 w-32" />
                    <Skeleton className="h-7 w-16 rounded-full" />
                  </div>
                  <Skeleton className="h-4 w-full mt-2" />
                  <Skeleton className="h-4 w-3/4 mt-2" />
                  <Skeleton className="h-10 w-32 rounded-full mt-4" />
                </CardContent>
              </Card>
            ))
          ) : filteredItems.length > 0 ? (
            filteredItems.map((item) => (
              <Card 
                key={item.id} 
                className="menu-item bg-white rounded-lg shadow-md overflow-hidden menu-transition hover:shadow-lg"
              >
                <img 
                  src={item.imageUrl} 
                  alt={item.name} 
                  className="w-full h-48 object-cover" 
                />
                <CardContent className="p-6">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-playfair text-xl font-semibold">{item.name}</h3>
                    <span className="bg-[hsl(var(--coffee-secondary))] text-[hsl(var(--coffee-primary))] px-3 py-1 rounded-full text-sm font-medium">
                      {item.price} ₸
                    </span>
                  </div>
                  <p className="text-gray-600 mb-4">{item.description}</p>
                  <Button 
                    className="bg-[hsl(var(--coffee-primary))] hover:bg-[hsl(var(--coffee-accent))] text-white rounded-full text-sm"
                  >
                    Себетке қосу
                  </Button>
                </CardContent>
              </Card>
            ))
          ) : (
            // Fallback menu items when API returns empty
            <div className="col-span-full text-center py-8">
              <p className="text-gray-500">Бұл санатта тағамдар табылмады</p>
            </div>
          )}
        </div>
        
        <div className="text-center mt-16">
          <a href="#order">
            <Button className="bg-[hsl(var(--coffee-primary))] hover:bg-[hsl(var(--coffee-accent))] text-white font-medium py-6 px-8 rounded-full">
              Толық мәзірді көру
            </Button>
          </a>
        </div>
      </div>
    </section>
  );
}
