import { useRef, useEffect } from 'react';
import * as THREE from 'three';
import { Text } from 'troika-three-text';

export default function CoffeeModel() {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    // Setup
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, 1.5, 0.1, 1000);
    camera.position.z = 8;
    camera.position.y = 3;

    const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    renderer.setSize(400, 300);
    renderer.setClearColor(0x000000, 0);
    
    if (containerRef.current.firstChild) {
      containerRef.current.removeChild(containerRef.current.firstChild);
    }
    containerRef.current.appendChild(renderer.domElement);

    // Create a cafe building
    const buildingGroup = new THREE.Group();
    
    // Main building body
    const buildingGeometry = new THREE.BoxGeometry(4, 2.5, 3);
    const buildingMaterial = new THREE.MeshBasicMaterial({ 
      color: 0xE6D2B5, // Light warm beige color for cafe
    });
    const building = new THREE.Mesh(buildingGeometry, buildingMaterial);
    buildingGroup.add(building);
    
    // Roof
    const roofGeometry = new THREE.ConeGeometry(3, 1.5, 4);
    const roofMaterial = new THREE.MeshBasicMaterial({ color: 0x8B5D33 }); // Brown roof
    const roof = new THREE.Mesh(roofGeometry, roofMaterial);
    roof.position.y = 2;
    roof.rotation.y = Math.PI / 4; // Rotate to make it look better
    buildingGroup.add(roof);
    
    // Door
    const doorGeometry = new THREE.PlaneGeometry(0.8, 1.5);
    const doorMaterial = new THREE.MeshBasicMaterial({ 
      color: 0x5D4037,
      side: THREE.DoubleSide
    });
    const door = new THREE.Mesh(doorGeometry, doorMaterial);
    door.position.set(0, -0.5, 1.51); // Position at front of building
    buildingGroup.add(door);
    
    // Windows
    const windowGeometry = new THREE.PlaneGeometry(0.7, 0.7);
    const windowMaterial = new THREE.MeshBasicMaterial({ 
      color: 0xAED6F1,
      side: THREE.DoubleSide
    });
    
    // Left window
    const leftWindow = new THREE.Mesh(windowGeometry, windowMaterial);
    leftWindow.position.set(-1.5, 0.3, 1.51);
    buildingGroup.add(leftWindow);
    
    // Right window
    const rightWindow = new THREE.Mesh(windowGeometry, windowMaterial);
    rightWindow.position.set(1.5, 0.3, 1.51);
    buildingGroup.add(rightWindow);
    
    // Signboard
    const signGeometry = new THREE.PlaneGeometry(2, 0.5);
    const signMaterial = new THREE.MeshBasicMaterial({ 
      color: 0xD4A76A,
      side: THREE.DoubleSide
    });
    const sign = new THREE.Mesh(signGeometry, signMaterial);
    sign.position.set(0, 1.5, 1.6);
    buildingGroup.add(sign);
    
    // Ground/base
    const groundGeometry = new THREE.PlaneGeometry(8, 8);
    const groundMaterial = new THREE.MeshBasicMaterial({ 
      color: 0x7D8F69,
      side: THREE.DoubleSide
    });
    const ground = new THREE.Mesh(groundGeometry, groundMaterial);
    ground.rotation.x = Math.PI / 2;
    ground.position.y = -1.25;
    buildingGroup.add(ground);
    
    // Position the whole building group
    buildingGroup.position.y = -1;
    scene.add(buildingGroup);

    // Add a text label
    const myText = new Text();
    // Set properties to configure:
    myText.text = 'Café Aroma';
    myText.fontSize = 0.3;
    myText.position.set(0, 1.5, 1.61); // Position just in front of the sign
    myText.color = 0xFFFFFF;
    myText.anchorX = 'center';
    myText.anchorY = 'middle';
    myText.font = 'https://fonts.gstatic.com/s/playfairdisplay/v30/nuFvD-vYSZviVYUb_rj3ij__anPXJzDwcbmjWBN2PKdFvUDQZNLo_U2r.woff2';
    
    // Update the rendering:
    myText.sync();
    scene.add(myText);
    
    // Add address text
    const addressText = new Text();
    addressText.text = 'Жетісу 2 16а';
    addressText.fontSize = 0.2;
    addressText.position.set(0, -0.7, 1.52); // Under the door
    addressText.color = 0x000000;
    addressText.anchorX = 'center';
    addressText.anchorY = 'middle';
    addressText.font = 'https://fonts.gstatic.com/s/roboto/v30/KFOmCnqEu92Fr1Mu4mxK.woff2';
    addressText.sync();
    scene.add(addressText);

    // Animation
    function animate() {
      requestAnimationFrame(animate);
      
      // Rotate the building slightly
      buildingGroup.rotation.y += 0.005;
      
      renderer.render(scene, camera);
    }
    
    animate();

    // Cleanup on component unmount
    return () => {
      if (containerRef.current?.contains(renderer.domElement)) {
        containerRef.current.removeChild(renderer.domElement);
      }
      
      // Dispose resources
      buildingGeometry.dispose();
      buildingMaterial.dispose();
      roofGeometry.dispose();
      roofMaterial.dispose();
      doorGeometry.dispose();
      doorMaterial.dispose();
      windowGeometry.dispose();
      windowMaterial.dispose();
      signGeometry.dispose();
      signMaterial.dispose();
      groundGeometry.dispose();
      groundMaterial.dispose();
      renderer.dispose();
    };
  }, []);

  return (
    <div 
      ref={containerRef} 
      className="flex justify-center items-center" 
      style={{ height: '350px', width: '100%' }}
    />
  );
}