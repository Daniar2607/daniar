declare module 'troika-three-text' {
  import { Object3D } from 'three';

  export class Text extends Object3D {
    text: string;
    fontSize: number;
    color: number | string;
    anchorX: 'left' | 'center' | 'right';
    anchorY: 'top' | 'top-baseline' | 'middle' | 'bottom-baseline' | 'bottom';
    font: string;
    sync(): void;
  }
}